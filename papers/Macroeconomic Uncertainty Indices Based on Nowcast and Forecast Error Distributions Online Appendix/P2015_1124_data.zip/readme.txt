This readme file accompanies the paper titled �Macroeconomic Uncertainty Indices Based on Nowcast and Forecast Error Distributions� by Barbara Rossi and Tatevik Sekhposyan published in the American Economic Review: Papers and Proceedings, May 2015.

SPFIndex - contains the input data for constructing the SPF-based uncertainty indices. It also has the codes that generate the output-growth-based uncertainty indices presented in the paper and that based on inflation reported in the Online Appendix.

PooledIndex - contains the data and codes that generate uncertainty indices based on the simple average forecast from variety of ADL models. These are robustness results and are reported in the Online Appendix.

OtherIndices - contains the VXO, BBD and JLN indices that we compare our indices to. It excludes the Scotti index since that was provided by the author separately.

VAR - has the data, codes and results in regards to the macroeconomic effects of the various uncertainty indices.