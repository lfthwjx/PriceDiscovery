load ipplot.mat
plot_variance = @(x,lower,upper,color) set(fill([x,x(end:-1:1)],[upper,lower(end:-1:1)],color),'EdgeColor',color);

dateforplot = 1:length(ipplot);

figure
plot_variance(dateforplot,ipplot(:,5)',ipplot(:,1)',[0.9 0.9 0.9])
hold on
plot(ipplot(:,2),'Linewidth',2)
hold on
plot(ipplot(:,3),':','Linewidth',2)
hold on
plot(ipplot(:,4),'-g','Linewidth',2)
hold on
plot(zeros(length(ipplot),1),'-k','Linewidth',2)
hold off
xlim([1 length(ipplot)])
ylim([-5 2])
legend('U_{t+h}^* bands','U_{t+h}^-','U_{t+h}^*','U_{t+h}^+')
title('IP')
xlabel('quarters')
grid on
box on
