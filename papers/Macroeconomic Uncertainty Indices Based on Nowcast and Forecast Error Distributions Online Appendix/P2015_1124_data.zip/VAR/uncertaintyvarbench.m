clear all

% Sets up the data in the form considered in the paper
%[rdata labels] = xlsread('vardataextendGDPnorm.xlsx','VXO');
[rdata labels] = xlsread('vardataextendIPnorm.xlsx','RSDownside');

tlabels = labels(1,2:end);
trans = rdata(1,2:end);
rawdata = rdata(:,2:end);

tdata(:,(trans==1)) = rawdata(2:end,(trans==1));
tdata(:,(trans==2)) = log(rawdata(2:end,(trans==2)))*100;
tdata(:,(trans==5)) = log(rawdata(2:end,(trans==5)))*100;
tdatatemp = tdata;
clear tdata
tdata = tdatatemp(:,end:-1:1);

h = 20;
plotfigures = 1;

nlags = mbic(tdata, tdata, [cumsum(ones(size(tdata,1),1)) ones(size(tdata,1),1)], 4);

yy = tdata(nlags+1:end,:);
[depnobs nvars] = size(yy);

yylagtemp = [];
for i = 1:nlags
    yylagtemp = [yylagtemp lagmatrix(tdata,i)];
end
yylag = [yylagtemp(nlags+1:end,:) cumsum(ones(depnobs,1)) ones(depnobs,1)];


% ESTIMATE VAR
xxx = inv(yylag'*yylag); % (x?x)^(-1) matrix
b = xxx*(yylag'*yy);     % ols estimator (this is a system wide estimator)
res = yy - yylag*b;      % residuals
vmat = (1/depnobs)*(res'*res); %vcov of residuals
stds = sqrt(diag(vmat)); % Std devs of residuals
seb = sqrt(diag(xxx)*(diag(vmat)')); % STANDARD ERRORS estimated coefficients

% IMPOSE IDENTIFICATION
a = chol(vmat)';  % Cholesky decomp of vmat

irmean = impulseresponse(b,a,nlags,h);

% BOOTSTRAP
randn('seed',195748);
rand('seed',684512);
randn(5000);
for ii = 1:2000
    clear yybootlag
    resres = datasample(res,depnobs + nlags,1,'Replace',true);
    yybootinit = resres(1,:) + [1 1]*b(end-1:end,:);
    
    for kk = 2:nlags
        yybootinit = [yybootinit; [yybootinit(kk-1,:) repmat(zeros(1,nvars),1,(nlags-1)) kk 1]*b + resres(kk,:)];
    end
    
    yybootinittrans = yybootinit';
    yybootlag(1,:) = yybootinittrans(:);
    
    for jj = 2:depnobs+1
        yyboot(jj-1,:) = [yybootlag(jj-1,:) cumsum(nlags+jj-1) 1]*b + resres(nlags+jj-1,:);

        if jj ~= depnobs+1
            yybootlag(jj,:) = [yyboot(jj-1,:) yybootlag(jj-1,1:end-nvars)]; 
        end
    end
    
    trend = cumsum(ones(depnobs + nlags,1));
    yybootlag = [yybootlag trend(nlags+1:end,1) ones(depnobs,1)];
    xxxboot = (yybootlag'*yybootlag)^(-1);   % (x?x)^(-1) matrix
    bboot = xxxboot*(yybootlag'*yyboot);     % ols estimator (this is a system wide estimator)
    resboot = yyboot - yybootlag*bboot;      % residuals
    vmatboot = (1/depnobs)*(resboot'*resboot); %vcov of residuals
    
    % IMPOSE IDENTIFICATION
    aboot = chol(vmatboot)';  % Cholesky decomp of vmat

    ir(:,:,ii) = impulseresponse(bboot,aboot,nlags,h);
end

irbands = prctile(ir, [5 95], 3);

if (plotfigures == 1)
    figure
    plot(irmean(1,:),'Linewidth',2)
    hold on
    plot(irbands(1,:,1),':','Linewidth',2)
    hold on
    plot(irbands(1,:,2),':','Linewidth',2)
    hold on
    plot(zeros(1,h),'-k','Linewidth',2)
    xlim([1 h])
    ylim([-5 2])
    %title('GDP')
    title('IP')
    xlabel('quarters')
    grid on
    box on
    
    figure
    plot(irmean(2,:),'Linewidth',2)
    hold on
    plot(irbands(2,:,1),':','Linewidth',2)
    hold on
    plot(irbands(2,:,2),':','Linewidth',2)
    hold on
    plot(zeros(1,h),'-k','Linewidth',2)
    xlim([1 h])
    ylim([-2 2])
    title('Employment')
    xlabel('quarters')
    grid on
    box on

    figure
    plot(irmean(3,:),'Linewidth',2)
    hold on
    plot(irbands(3,:,1),':','Linewidth',2)
    hold on
    plot(irbands(3,:,2),':','Linewidth',2)
    hold on
    plot(zeros(1,h),'-k','Linewidth',2)
    xlim([1 h])
    ylim([-2 2])
    title('Federal Funds Rate')
    xlabel('quarters')
    grid on
    box on

    figure
    plot(irmean(4,:),'Linewidth',2)
    hold on
    plot(irbands(4,:,1),':','Linewidth',2)
    hold on
    plot(irbands(4,:,2),':','Linewidth',2)
    hold on
    plot(zeros(1,h),'-k','Linewidth',2)
    xlim([1 h])
    title('S&P 500 Index')
    xlabel('quarters')
    ylim([-20 20])
    grid on
    box on

    figure
    plot(irmean(5,:),'Linewidth',2)
    hold on
    plot(irbands(5,:,1),':','Linewidth',2)
    hold on
    plot(irbands(5,:,2),':','Linewidth',2)
    hold on
    plot(zeros(1,h),'-k','Linewidth',2)
    xlim([1 h])
    title('Uncertainty Index')
    xlabel('quarters')
    ylim([-0.5 1])
    grid on
    box on
end