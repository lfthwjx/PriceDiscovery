load gdprs.mat
plot_variance = @(x,lower,upper,color) set(fill([x,x(end:-1:1)],[upper,lower(end:-1:1)],color),'EdgeColor',color)

dateforplot = 1:length(gdprs);

figure('Position',[0,0,600,360]);
plot_variance(dateforplot,gdprs(:,5)',gdprs(:,1)',[0.9 0.9 0.9]);
hold on
p2 = plot(gdprs(:,2),'Linewidth',2);
hold on
p3 = plot(gdprs(:,3),':','Linewidth',2);
hold on
p4 = plot(gdprs(:,4),'-g','Linewidth',2);
hold on
p5 = plot(zeros(length(gdprs),1),'-k','Linewidth',2);
hold on
xlim([1 length(gdprs)])
ylim([-2 2])
legend('U_{t+h}^* bands','U_{t+h}^-','U_{t+h}^*','U_{t+h}^+','Location','North','Orientation','Horizontal')
title('GDP','FontSize', 14) 
xlabel('quarters','FontSize', 14) 
set(gca,'fontsize',14)
grid on
box on
