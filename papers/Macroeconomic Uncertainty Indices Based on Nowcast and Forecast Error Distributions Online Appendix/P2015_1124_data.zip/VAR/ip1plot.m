load ipplot1.mat
plot_variance = @(x,lower,upper,color) set(fill([x,x(end:-1:1)],[upper,lower(end:-1:1)],color),'EdgeColor',color);

dateforplot = 1:length(ip1plot);

figure
plot_variance(dateforplot,ip1plot(:,6)',ip1plot(:,1)',[0.9 0.9 0.9])
hold on
plot(ip1plot(:,2),':','Linewidth',2)
hold on
plot(ip1plot(:,3),'Linewidth',2)
hold on
plot(ip1plot(:,4),'-.b','Linewidth',2)
hold on
plot(ip1plot(:,5),'--b','Linewidth',2)
hold on
plot(zeros(length(ip1plot),1),'-k','Linewidth',2)
hold off
xlim([1 length(ip1plot)])
ylim([-5 2])
legend('VXO bands','VXO','BBD','JLN','Scotti')
title('IP')
xlabel('quarters')
grid on
box on