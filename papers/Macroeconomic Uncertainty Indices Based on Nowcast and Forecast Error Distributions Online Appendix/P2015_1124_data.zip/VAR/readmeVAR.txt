This is a readme file for the VAR results described in Figure 3 of the main text and in Figures A5 and A6 of the Appendix. 

DATA FILES
vardataextendGDPnorm.xlsx - The data that goes into the VAR with GDP specification.
vardataextendIPnorm.xlsx - The data that goes into the VAR with IP specification.

PROGRAM FILES
uncertaintyvarbench.m - runs the benchmark specification of the VAR with the GDP.
uncertaintyvar.m - runs the VAR with the alternative ordering of BBD. When running the uncertaintyvarbench.m or uncertaintyvar.m then please make sure to change shock identifier in the impulseresponse.m file. 
impulseresponse.m - constructs the impulse responses.
mbic - selects the lag length with BIC.

PLOTTING FILES
empplot.m, emp1plot.m, gdpplot.m, gdp1plot.m, ipplot.m, ip1plot.m - supporting plotting files
