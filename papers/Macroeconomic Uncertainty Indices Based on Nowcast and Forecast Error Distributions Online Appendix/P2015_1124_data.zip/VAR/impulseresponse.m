function ir = impulseresponse(b,a,nlags,h)

% COMPANION FORM
%   form the companion matrix
b = b';
[N,k] = size(b);

e = zeros(N,1);
e(end,1) = 1/a(end,end);

b_ = b(:,1:end-2);

aa = eye(N * (nlags-1));
bb = zeros(N * (nlags-1),N);
S = [eye(N, N) bb'];
GAMA = [b_ ; [aa bb]];
ir = zeros(N,h);
for i = 1:h
    ir(:,i) = (S*GAMA ^ (i-1)*S') * a * e ;
end