load gdprs1.mat
plot_variance = @(x,lower,upper,color) set(fill([x,x(end:-1:1)],[upper,lower(end:-1:1)],color),'EdgeColor',color);

dateforplot = 1:length(gdprs1);

figure('Position',[0,0,600,360]);
plot_variance(dateforplot,gdprs1(:,6)',gdprs1(:,1)',[0.9 0.9 0.9])
hold on
plot(gdprs1(:,2),':','Linewidth',2)
hold on
plot(gdprs1(:,3),'Linewidth',2)
hold on
plot(gdprs1(:,4),'-.b','Linewidth',2)
hold on
plot(gdprs1(:,5),'--b','Linewidth',2)
hold on
plot(zeros(length(gdprs1),1),'-k','Linewidth',2)
xlim([1 length(gdprs1)])
ylim([-2 2])
legend('VXO bands','VXO','BBD','JLN','Scotti','Location','North','Orientation','Horizontal')
title('GDP','fontsize',14)
xlabel('quarters','fontsize',14)
set(gca,'fontsize',14)
grid on
box on