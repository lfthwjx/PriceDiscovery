% Constructs the unconditional distribution of forecast errors from SPF
% point forecasts for real GDP growth
clear all

% read data
[rawdata metadata] = xlsread('SPFDataCompleteYoY.xlsx','RGDP' );
[rawdataexog metadataexog] = xlsread('SPFDataCompleteYoY.xlsx','Exogeneous' );

dateexog = rawdataexog(2:end,1);
dataexog = rawdataexog(2:end,2:end);

date = rawdata(2:end,3);
data = rawdata(2:end,4:end);
fcst_hor = rawdata(1,4:end);

fcst_err0 = data(:,fcst_hor == 111);
fcst_err4 = data(:,fcst_hor == 555);

% clean the data from NaNs
fcst_err0_cl = fcst_err0(isnan(fcst_err0) == 0);
date_err0 = date(isnan(fcst_err0) == 0);
data_exog0_cl = dataexog(isnan(fcst_err0) == 0,:);

fcst_err4_cl = fcst_err4(isnan(fcst_err4) == 0);
date_err4 = date(isnan(fcst_err4) == 0);
data_exog4_cl = dataexog(isnan(fcst_err4) == 0,:);

% constructs the unconditional distribution
% calculate the time series of the uncertainty
index0 = find(date_err0 >= 1984.75);
index4 = find(date_err4 >= 1984.75);

date_err0_sel = date_err0(index0+1:end,:);
date_err4_sel = date_err4(index4+1:end,:);

data_exog0_sel = data_exog0_cl(index0+1:end,:);
data_exog4_sel = data_exog4_cl(index4+1:end,:);

p0 = [];
for ii = index0(1,1):size(fcst_err0_cl,1)-1
    fcst_err0_sel = fcst_err0_cl(1:ii);
    sortedfe0 = sort(fcst_err0_sel);
    freqfe0 = cumsum(ones(size(sortedfe0)));
    freqfe0 = freqfe0./freqfe0(end,1); 
    
    selx = find(sortedfe0 <= fcst_err0_cl(ii+1));
    
    if (isempty(selx) == 1)
        p0 = [p0; 0];
    else
        p0 = [p0; freqfe0(selx(end)) + (freqfe0(selx(end)+1)-freqfe0(selx(end)))/(sortedfe0(selx(end)+1) - sortedfe0(selx(end)))*(fcst_err0_cl(ii+1)- sortedfe0(selx(end)))];
    end
end

p4 = [];
for ii = index4(1,1):size(fcst_err4_cl,1)-1
    fcst_err4_sel = fcst_err4_cl(1:ii);
    sortedfe4 = sort(fcst_err4_sel);
    freqfe4 = cumsum(ones(size(sortedfe4)));
    freqfe4 = freqfe4./freqfe4(end,1); 
        
    selx = find(sortedfe4 <= fcst_err4_cl(ii+1));
    if (isempty(selx) == 1)
        p4 = [p4; 0];
    else
        p4 = [p4; freqfe4(selx(end)) + (freqfe4(selx(end)+1)-freqfe4(selx(end)))/(sortedfe4(selx(end)+1) - sortedfe4(selx(end)))*(fcst_err4_cl(ii+1)- sortedfe4(selx(end)))];
    end
end

% constructs upside and downside uncertainty
for jj = 1:length(p0)   
    u0_ups(jj,1) = 0.5 + max(p0(jj,1)-0.5,0);
    u0_down(jj,1) = 0.5 + max(0.5-p0(jj,1),0);
    u0(jj,1) = 0.5 + abs(p0(jj,1)-0.5);
end

for jj = 1:length(p4)   
    for jj = 1:length(p4)   
        u4_ups(jj,1) = 0.5 + max(p4(jj,1)-0.5,0);
        u4_down(jj,1) = 0.5 + max(0.5-p4(jj,1),0);
        u4(jj,1) = 0.5 + abs(p4(jj,1)-0.5);
    end
end

bands0 = quantile(u0, [0.9; 0.1]);
bands4 = quantile(u4, [0.9; 0.1]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% PLOTS %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% plot the uncertainty indices and recession dates
grayColor = [1 1 1] * 0.7; 
figure('Position',[0,0,600,360]);
p1 = bar(date_err0_sel,data_exog0_sel(:,1)*4,'FaceColor', grayColor, 'EdgeColor',grayColor);
hold on
p2 = plot(date_err0_sel, u0,'LineWidth',2);
hold on
p3 = plot(date_err0_sel, 0.5*ones(size(date_err0_sel)), '-k', 'LineWidth', 2);
hold off
box on
legend([p1,p2],{'Recession Dates','U_{t+h}^*'},'Location','South', 'Orientation','Horizontal','FontSize', 14) 
title('Real-time Uncertainty in SPF Nowcasts','FontSize', 14) 
ylim([0.45 1])
xlim([min(date_err0_sel) max(date_err0_sel)])
set(gca,'fontsize',14)

figure('Position',[0,0,600,360]);
p1 = bar(date_err0_sel,data_exog0_sel(:,1)*4,'FaceColor', grayColor, 'EdgeColor',grayColor);
hold on
p2 = bar(date_err0_sel, u0_down, 'FaceColor',[0,0,1],'EdgeColor',[0,0,1]);
hold on
p3 = bar(date_err0_sel, u0_ups, 'FaceColor',[0,1,0],'EdgeColor',[0,1,0]);
hold on
p4 = plot(date_err0_sel, 0.5*ones(size(date_err0_sel)), '-k', 'LineWidth', 2);
hold off
box on
legend([p1, p2, p3], {'Recession Dates','U_{t+h}^-', 'U_{t+h}^+'},'Location','North', 'Orientation','Horizontal','FontSize', 14)
title('Real-time Uncertainty in SPF Nowcasts','FontSize', 14) 
ylim([0.5 1.1])
xlim([min(date_err0_sel) max(date_err0_sel)])
set(gca,'fontsize',14)
h1 = gca;
h2 = axes('Position',get(h1,'Position'));
plot(date_err0,bands0(1,1).*ones(size(date_err0)),':r','LineWidth',2)
set(h2,'YAxisLocation','right','Color','none','XTickLabel',[],'YTickLabel',[])
set(h2,'XLim',get(h1,'XLim'),'Layer','top')

figure('Position',[0,0,600,360]);
p1 = bar(date_err4_sel,data_exog4_sel(:,1)*4,'FaceColor', grayColor, 'EdgeColor',grayColor);
hold on
p2 = plot(date_err4_sel, u4,'LineWidth',2);
hold on
p3 = plot(date_err4_sel, 0.5*ones(size(date_err4_sel)), '-k', 'LineWidth', 2);
hold off
box on
legend([p1,p2],{'Recession Dates','U_{t+h}^*'},'Location','South', 'Orientation','Horizontal','FontSize', 14) 
title('Real-time Uncertainty in SPF Four-Quarters-Ahead Forecasts','FontSize', 14) 
ylim([0.45 1])
xlim([min(date_err4_sel) max(date_err4_sel)])
set(gca,'fontsize',14)

figure('Position',[0,0,600,360]);
p1 = bar(date_err4_sel,data_exog4_sel(:,1)*4,'FaceColor', grayColor, 'EdgeColor',grayColor);
hold on
p2 = bar(date_err4_sel, u4_down,'FaceColor',[0,0,1],'EdgeColor',[0,0,1]);
hold on
p3 = bar(date_err4_sel, u4_ups,'FaceColor',[0,1,0],'EdgeColor',[0,1,0]);
hold on
p4 = plot(date_err4_sel, 0.5*ones(size(date_err4_sel)), '-k', 'LineWidth', 2);
hold off
box on
legend([p1, p2, p3],{'Recession Dates','U_{t+h}^-', 'U_{t+h}^+'},'Location','North', 'Orientation','Horizontal','FontSize', 14) 
title('Real-time Uncertainty in SPF Four-Quarters-Ahead Forecasts','FontSize', 14) 
ylim([0.5 1.1])
xlim([min(date_err4_sel) max(date_err4_sel)])
set(gca,'fontsize',14)
h1 = gca;
h2 = axes('Position',get(h1,'Position'));
plot(date_err4,bands4(1,1).*ones(size(date_err4)),':r','LineWidth',2)
set(h2,'YAxisLocation','right','Color','none','XTickLabel',[],'YTickLabel',[])
set(h2,'XLim',get(h1,'XLim'),'Layer','top')