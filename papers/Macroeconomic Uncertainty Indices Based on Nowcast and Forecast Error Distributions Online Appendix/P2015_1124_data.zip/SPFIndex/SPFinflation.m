% Constructs the unconditional distribution of forecast errors from SPF
% point forecasts for real GDP growth
clear all

% read data
[rawdata metadata] = xlsread('SPFDataCompleteYoY.xlsx','PGDP' );
[rawdataexog metadataexog] = xlsread('SPFDataCompleteYoY.xlsx','Exogeneous' );

dateexog = rawdataexog(2:end,1);
dataexog = rawdataexog(2:end,2:end);

date = rawdata(2:end,3);
data = rawdata(2:end,4:end);
fcst_hor = rawdata(1,4:end);

fcst_err0 = data(:,fcst_hor == 111);
fcst_err4 = data(:,fcst_hor == 555);

% clean the data from NaNs
fcst_err0_cl = fcst_err0(isnan(fcst_err0) == 0);
date_err0 = date(isnan(fcst_err0) == 0);
data_exog0_cl = dataexog(isnan(fcst_err0) == 0,:);

fcst_err4_cl = fcst_err4(isnan(fcst_err4) == 0);
date_err4 = date(isnan(fcst_err4) == 0);
data_exog4_cl = dataexog(isnan(fcst_err4) == 0,:);

% constructs the unconditional distribution
sortedfe0 = sort(fcst_err0_cl);
sortedfe4 = sort(fcst_err4_cl);

freqfe0 = cumsum(ones(size(sortedfe0)));
freqfe4 = cumsum(ones(size(sortedfe4)));
freqfe0 = freqfe0./freqfe0(end,1);
freqfe4 = freqfe4./freqfe4(end,1);

% calculate the time series of the uncertainty
for ii = 1:length(date_err0)
    p0(ii,:) = freqfe0(sortedfe0 ==  fcst_err0_cl(date_err0 == date_err0(ii,1)));
end

for ii = 1:length(date_err4)
    p4(ii,:) = freqfe4(sortedfe4 ==  fcst_err4_cl(date_err4 == date_err4(ii,1)));
end

% constructs upside and downside uncertainty
for jj = 1:length(p0)   
    u0_downs(jj,1) = 0.5 + max(p0(jj,1)-0.5,0);
    u0_upss(jj,1) = 0.5 + max(0.5-p0(jj,1),0);
    u0(jj,1) = 0.5 + abs(p0(jj,1)-0.5);
end

for jj = 1:length(p4)   
    for jj = 1:length(p4)   
        u4_downs(jj,1) = 0.5 + max(p4(jj,1)-0.5,0);
        u4_upss(jj,1) = 0.5 + max(0.5-p4(jj,1),0);
        u4(jj,1) = 0.5 + abs(p4(jj,1)-0.5);
    end
end

% identify event dates
fcst_err0_lehman = fcst_err0_cl(date_err0 == 2008.5);
fcst_err4_lehman = fcst_err4_cl(date_err4 == 2008.5);

fcst_err0_postrec = fcst_err0_cl(date_err0 == 2009.5);
fcst_err4_postrec = fcst_err4_cl(date_err4 == 2009.5);

p0_lehman = freqfe0(sortedfe0 ==  fcst_err0_lehman,:);
p0_postrec = freqfe0(sortedfe0 ==  fcst_err0_postrec,:);

p4_lehman = freqfe4(sortedfe4 ==  fcst_err4_lehman,:);
p4_postrec = freqfe4(sortedfe4 ==  fcst_err4_postrec,:);

data_exog0_lehman = data_exog0_cl(date_err0 == 2008.5,:);
data_exog4_lehman = data_exog4_cl(date_err4 == 2008.5,:);

data_exog0_postrec = data_exog0_cl(date_err0 == 2009.5,:);
data_exog4_postrec = data_exog4_cl(date_err4 == 2009.5,:);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% PLOTS %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% plot the figures in the example
% plot the uncertainty indices and recession dates
grayColor = [1 1 1] * 0.7; 
figure
bar(date_err0,data_exog0_cl(:,1)*4,'FaceColor', grayColor, 'EdgeColor',grayColor)
hold on
plot(date_err0, u0,'LineWidth',2)
hold on
plot(date_err0, 0.5*ones(size(date_err0)), '-k', 'LineWidth', 2)
hold off
box on
legend('Recession Dates','U_{t+h}^*','Location','South', 'Orientation','Horizontal')
title('Uncertainty in SPF Nowcasts')
ylim([0.45 1])
xlim([min(date_err0) max(date_err0)])

figure
bar(date_err0,data_exog0_cl(:,1)*4,'FaceColor', grayColor, 'EdgeColor',grayColor)
hold on
bar(date_err0, u0_upss, 'FaceColor',[0,0,1],'EdgeColor',[0,0,1])
hold on
bar(date_err0, u0_downs, 'FaceColor',[0,1,0],'EdgeColor',[0,1,0])
hold on
plot(date_err0, 0.5*ones(size(date_err0)), '-k', 'LineWidth', 2)
hold off
box on
legend('Recession Dates','U_{t+h}^-', 'U_{t+h}^+','Location','North', 'Orientation','Horizontal')
title('Uncertainty in SPF Nowcasts')
ylim([0.5 1.1])
xlim([min(date_err0) max(date_err0)])

figure
bar(date_err4,data_exog4_cl(:,1)*4,'FaceColor', grayColor, 'EdgeColor',grayColor)
hold on
plot(date_err4, u4,'LineWidth',2)
hold on
plot(date_err4, 0.5*ones(size(date_err4)), '-k', 'LineWidth', 2)
hold off
box on
legend('Recession Dates','U_{t+h}^*','Location','South', 'Orientation','Horizontal')
title('Uncertainty in SPF Four-Quarters-Ahead Forecasts')
ylim([0.45 1])
xlim([min(date_err4) max(date_err4)])

figure
bar(date_err4,data_exog4_cl(:,1)*4,'FaceColor', grayColor, 'EdgeColor',grayColor)
hold on
bar(date_err4, u4_upss,'FaceColor',[0,0,1],'EdgeColor',[0,0,1])
hold on
bar(date_err4, u4_downs,'FaceColor',[0,1,0],'EdgeColor',[0,1,0])
hold on
plot(date_err4, 0.5*ones(size(date_err4)), '-k', 'LineWidth', 2)
hold off
box on
legend('Recession Dates','U_{t+h}^-', 'U_{t+h}^+','Location','North', 'Orientation','Horizontal')
title('Uncertainty in SPF Four-Quarters-Ahead Forecasts')
ylim([0.5 1.1])
xlim([min(date_err4) max(date_err4)])