% Constructs the unconditional distribution of forecast errors from SPF
% point forecasts for real GDP growth
% replicates Figure 2, top 2 panesl
clear all

% read data
[rawdata metadata] = xlsread('SPFDataCompleteYoY.xlsx','RGDP' );
[rawdataexog metadataexog] = xlsread('SPFDataCompleteYoY.xlsx','Exogeneous' );

dateexog = rawdataexog(2:end,1);
dataexog = rawdataexog(2:end,2:end);

date = rawdata(2:end,3);
data = rawdata(2:end,4:end);
fcst_hor = rawdata(1,4:end);

fcst_err0 = data(:,fcst_hor == 111);
fcst_err4 = data(:,fcst_hor == 555);

% clean the data from NaNs
fcst_err0_cl = fcst_err0(isnan(fcst_err0) == 0);
date_err0 = date(isnan(fcst_err0) == 0);
data_exog0_cl = dataexog(isnan(fcst_err0) == 0,:);

fcst_err4_cl = fcst_err4(isnan(fcst_err4) == 0);
date_err4 = date(isnan(fcst_err4) == 0);
data_exog4_cl = dataexog(isnan(fcst_err4) == 0,:);

% constructs the unconditional distribution
sortedfe0 = sort(fcst_err0_cl);
sortedfe4 = sort(fcst_err4_cl);

freqfe0 = cumsum(ones(size(sortedfe0)));
freqfe4 = cumsum(ones(size(sortedfe4)));
freqfe0 = freqfe0./freqfe0(end,1);
freqfe4 = freqfe4./freqfe4(end,1);

% calculate the time series of the uncertainty
for ii = 1:length(date_err0)
    p0(ii,:) = freqfe0(sortedfe0 ==  fcst_err0_cl(date_err0 == date_err0(ii,1)));
end

for ii = 1:length(date_err4)
    p4(ii,:) = freqfe4(sortedfe4 ==  fcst_err4_cl(date_err4 == date_err4(ii,1)));
end

% constructs upside and downside uncertainty
for jj = 1:length(p0)   
    u0_ups(jj,1) = 0.5 + max(p0(jj,1)-0.5,0);
    u0_down(jj,1) = 0.5 + max(0.5-p0(jj,1),0);
    u0(jj,1) = 0.5 + abs(p0(jj,1)-0.5);
end


for jj = 1:length(p4)   
    u4_ups(jj,1) = 0.5 + max(p4(jj,1)-0.5,0);
    u4_down(jj,1) = 0.5 + max(0.5-p4(jj,1),0);
    u4(jj,1) = 0.5 + abs(p4(jj,1)-0.5);
end

bands0 = quantile(u0, [0.9; 0.1]);
bands4 = quantile(u4, [0.9; 0.1]);

% identify event dates
% these construct the measures for Plot 1
fcst_err0_lehman = fcst_err0_cl(date_err0 == 2008.5);
fcst_err4_lehman = fcst_err4_cl(date_err4 == 2008.5);

fcst_err0_postrec = fcst_err0_cl(date_err0 == 2009.5);
fcst_err4_postrec = fcst_err4_cl(date_err4 == 2009.5);

p0_lehman = freqfe0(sortedfe0 ==  fcst_err0_lehman,:);
p0_postrec = freqfe0(sortedfe0 ==  fcst_err0_postrec,:);

p4_lehman = freqfe4(sortedfe4 ==  fcst_err4_lehman,:);
p4_postrec = freqfe4(sortedfe4 ==  fcst_err4_postrec,:);

data_exog0_lehman = data_exog0_cl(date_err0 == 2008.5,:);
data_exog4_lehman = data_exog4_cl(date_err4 == 2008.5,:);

data_exog0_postrec = data_exog0_cl(date_err0 == 2009.5,:);
data_exog4_postrec = data_exog4_cl(date_err4 == 2009.5,:);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% PLOTS %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% plot the figures in the example
[f4,xi4] = ksdensity(fcst_err4_cl);
figure('Position',[0,0,600,360]);
p1 = bar(fcst_err4_lehman, max(f4./sum(f4)),0.005,'b','EdgeColor','b');
hold on
p2 = bar(fcst_err4_postrec, max(f4./sum(f4)),0.005,'Facecolor',[0,1,0],'EdgeColor',[0,1,0]);
hold on
p3 = plot(xi4,f4./sum(f4),'--bo'); 
hold off
box on
legend([p1,p2,p3],{'2008:III','2009:III','Distribution '},'Location','Best','FontSize', 14) 
title('PDF of Four-Quarters-Ahead forecast errors','FontSize', 14) 
set(gca,'fontsize',14)
set(gca,'YTick',[0:0.01:0.05])

figure('Position',[0,0,600,360]);
p1 = bar(fcst_err4_lehman, p4_lehman,0.01,'b','EdgeColor','b');
hold on
p2 = bar(fcst_err4_postrec,p4_postrec,0.01,'Facecolor',[0,1,0],'EdgeColor',[0,1,0]);
hold on
[h,stats] = cdfplot(fcst_err4_cl);
set(h,'Color','b','Marker','o','LineStyle','--','MarkerSize',2)
hold off
box on
legend([p1,p2,h],{'2008:III','2009:III','Distribution '},'Location','Best','FontSize', 14) 
title('CDF of Four-Quarters-Ahead forecast errors','FontSize', 14) 
set(gca,'fontsize',14)

figure('Position',[0,0,600,360]);
p1 = bar(fcst_err4_lehman,0.5 + max(0.5 - p4_lehman,0),0.025,'b','EdgeColor','b');
hold on
p2 = bar(fcst_err4_postrec,0.5 + max(p4_postrec - 0.5,0),0.025,'Facecolor',[0,1,0],'EdgeColor',[0,1,0]);
hold off
box on
grid on
legend([p1,p2],{'U_{t+h}^- - 2008:III','U_{t+h}^+ - 2009:III'},'Location','Best','FontSize', 14) 
title('Uncertainty Index based on Four-Quarters-Ahead Forecast','FontSize', 14) 
xlim([min(fcst_err4) max(fcst_err4)])
ylim([0.5 1])
set(gca,'fontsize',14)

% plot the uncertainty indices and recession dates
grayColor = [1 1 1] * 0.7; 
figure('Position',[0,0,600,360]);
p1 = bar(date_err0,data_exog0_cl(:,1)*4,'FaceColor', grayColor, 'EdgeColor',grayColor);
hold on
p2 = plot(date_err0, u0,'LineWidth',2);
hold on
p3 = plot(date_err0, 0.5*ones(size(date_err0)), '-k', 'LineWidth', 2);
hold off
box on
legend([p1, p2],{'Recession Dates','U_{t+h}^*'},'Location','Best', 'FontSize', 14) 
title('Uncertainty in SPF Nowcasts','FontSize', 14) 
ylim([0.45 1.1])
xlim([min(date_err0) max(date_err0)])
set(gca,'fontsize',14)

figure('Position',[0,0,600,360]);
p1 = bar(date_err0,data_exog0_cl(:,1)*4,'FaceColor', grayColor, 'EdgeColor',grayColor);
hold on
p2 = bar(date_err0, u0_down, 'FaceColor',[0,0,1],'EdgeColor',[0,0,1]);
hold on
p3 = bar(date_err0, u0_ups, 'FaceColor',[0,1,0],'EdgeColor',[0,1,0]);
hold on
p4 = plot(date_err0, 0.5*ones(size(date_err0)), '-k', 'LineWidth', 2);
hold off
box on
legend([p1, p2, p3],{'Recessions','U_{t+h}^-', 'U_{t+h}^+'},'Location','North','Orientation','Horizontal', 'FontSize', 14) 
title('Uncertainty in SPF Nowcasts','FontSize', 14) 
ylim([0.5 1.1])
xlim([min(date_err0) max(date_err0)])
set(gca,'fontsize',14)
h1 = gca;
h2 = axes('Position',get(h1,'Position'));
plot(date_err0,bands0(1,1).*ones(size(date_err0)),':r','LineWidth',2)
set(h2,'YAxisLocation','right','Color','none','XTickLabel',[],'YTickLabel',[])
set(h2,'XLim',get(h1,'XLim'),'Layer','top')

figure('Position',[0,0,600,360]);
p1 = bar(date_err4,data_exog4_cl(:,1)*4,'FaceColor', grayColor, 'EdgeColor',grayColor);
hold on
p2 = plot(date_err4, u4,'LineWidth',2);
hold on
p3 = plot(date_err4, 0.5*ones(size(date_err4)), '-k', 'LineWidth', 2);
hold off
box on
legend([p1, p2],{'Recession Dates','U_{t+h}^*'},'Location','Best','FontSize', 14) 
title('Uncertainty in SPF Four-Quarters-Ahead Forecasts','FontSize', 14) 
ylim([0.45 1.1])
xlim([min(date_err4) max(date_err4)])
set(gca,'fontsize',14)


figure('Position',[0,0,600,360]);
p1 = bar(date_err4,data_exog4_cl(:,1)*4,'FaceColor', grayColor, 'EdgeColor',grayColor);
hold on
p2 = bar(date_err4, u4_down,'FaceColor',[0,0,1],'EdgeColor',[0,0,1]);
hold on
p3 = bar(date_err4, u4_ups,'FaceColor',[0,1,0],'EdgeColor',[0,1,0]);
hold on
p4 = plot(date_err4, 0.5*ones(size(date_err4)), '-k', 'LineWidth', 2);
hold off
box on
legend([p1, p2, p3],{'Recessions','U_{t+h}^-', 'U_{t+h}^+'},'Location','North','Orientation','Horizontal', 'FontSize', 14) 
title('Uncertainty in SPF Four-Quarters-Ahead Forecasts','FontSize', 14) 
ylim([0.5 1.1])
xlim([min(date_err4) max(date_err4)])
set(gca,'fontsize',14)
h1 = gca;
h2 = axes('Position',get(h1,'Position'));
plot(date_err4,bands4(1,1).*ones(size(date_err4)),':r','LineWidth',2)
set(h2,'YAxisLocation','right','Color','none','XTickLabel',[],'YTickLabel',[])
set(h2,'XLim',get(h1,'XLim'),'Layer','top')
