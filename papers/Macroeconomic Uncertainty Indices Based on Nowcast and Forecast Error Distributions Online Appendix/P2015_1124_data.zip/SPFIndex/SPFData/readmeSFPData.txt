This is a readme file describing how we construct the data used to back out the uncertainty index.

The data comes from the Federal Reserve Bank of Philadelphia.
The SPF data:
meanLevelSPFOrig.xls - original level for the SPF
http://www.philadelphiafed.org/research-and-data/real-time-center/survey-of-professional-forecasters/historical-data/mean-forecasts.cfm
meanLevelSPFTransformed.xls - transformed SPF files to calculate the quarterly growth rates of four-quarter-average annual real GDP levels.


The Real-time data used in the realizations:
PQvQdPRICES.xls
The original source is at the Philadelphia Fed http://www.philadelphiafed.org/research-and-data/real-time-center/real-time-data/data-files/P/
This is the transformed data series to obtain the quarterly growth rate of the four-quarter-average real prices
ROUTPUTQvQd.xls
The original source is at Philadelphia Fed http://www.philadelphiafed.org/research-and-data/real-time-center/real-time-data/data-files/ROUTPUT/
This is the transformed data series to obtain the quarterly growth rate of the four-quarter-average real GDP

Final transformed Series
SPFDataCompleteYoY.xls - includes the forecast, realizations, further calculates the forecast errors for multiple horizons. It includes an extra sheet 
With recession dates that are used for plotting.