This is a readme file describing how we construct the SPF based the uncertainty index.

The input file is the SPFDataCompleteYoY.xls - includes the forecast, realizations, further calculates the forecast errors for multiple horizons. It includes an extra sheet with recession dates that are used for plotting. For its construction please refer to the folder with SPFData.

SPFoutputgrowth.m - generates Figure 2, top 2 panels.
SPFoutputgrowthrealtime.m - generates Figure 2, bottom 2 panels.
SPFinflation.m - generates A3

SPFUncertaintySeriesOutputGrowth.xlsx has the revised and real-time uncertainty series, together with upside and downside uncertainty indices in both cases. 