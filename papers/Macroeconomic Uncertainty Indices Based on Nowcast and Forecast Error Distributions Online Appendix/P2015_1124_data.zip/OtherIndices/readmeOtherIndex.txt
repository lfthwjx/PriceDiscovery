This is a readme file describing how we construct the alternative indices.

uc_uncertainty_quarterly.xlsx - describes all the indices and walks through transformations used to get comparable indices with SPF in timing. 
The sheet "DataMidQuarter" reports the correlations Table 1.

figures.m constructs the figures in A1.
