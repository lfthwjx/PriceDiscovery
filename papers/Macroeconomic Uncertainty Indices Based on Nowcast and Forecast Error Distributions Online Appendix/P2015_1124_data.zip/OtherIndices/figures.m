clear all

% Sets up the data in the form considered in the paper
[rdata labels] = xlsread('us_uncertainty_quarterly.xlsx','FiguresMatlab');
date = rdata(:,1)

figure('Position',[0,0,600,360]);
plot(date, rdata(:,2),':b','LineWidth',2)
hold on
plot(date, rdata(:,end), 'g', 'LineWidth', 2)
hold off
box on
legend('VXO','U_{t+h}^*','Location','North', 'Orientation','Horizontal')
ylim([-2 6])
xlim([min(date) max(date)])
set(gca,'fontsize',14)

figure('Position',[0,0,600,360]);
plot(date, rdata(:,3),':b','LineWidth',2)
hold on
plot(date, rdata(:,end), 'g', 'LineWidth', 2)
hold off
box on
legend('BBD','U_{t+h}^*','Location','North', 'Orientation','Horizontal')
ylim([-2 6])
xlim([min(date) max(date)])
set(gca,'fontsize',14)

figure('Position',[0,0,600,360]);
plot(date, rdata(:,4),':b','LineWidth',2)
hold on
plot(date, rdata(:,end), 'g', 'LineWidth', 2)
hold off
box on
legend('JLN','U_{t+h}^*','Location','North', 'Orientation','Horizontal')
ylim([-2 6])
xlim([min(date) max(date)])
set(gca,'fontsize',14)

figure('Position',[0,0,600,360]);
plot(date, rdata(:,5),':b','LineWidth',2)
hold on
plot(date, rdata(:,end), 'g', 'LineWidth', 2)
hold off
box on
legend('Scotti','U_{t+h}^*','Location','North', 'Orientation','Horizontal')
ylim([-2 6])
xlim([min(date) max(date)])
set(gca,'fontsize',14)