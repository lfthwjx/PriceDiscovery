function data = getData(h)
% Sets up the data in the form considered in the paper
[rdata labels] = xlsread('Data.xls','FinalData');
recdatetemp = xlsread('Data.xls','RecDates');
recdates = recdatetemp(:,2);

tlabels = labels(1,2:end);
transf = rdata(1,2:end);
rawdata = rdata(:,2:end);

tdata(:,(transf==1)) = rawdata(3:end,(transf==1));
tdata(:,(transf==5)) = diff(log(rawdata(2:end,(transf==5))),1)*100;

if h == 1
    
    data.gdp  = tdata(2:end,16);
    data.pgdp = diff(tdata(2:end,21),1);
    zy = tdata(2:end, [1:15 17:20 22:end]);
    
    data.xgdp = tdata(1:end-1,16);
    data.xpgdp = diff(tdata(1:end-1,21),1);
    zx = tdata(1:end-1, [1:15 17:20 22:end]);

    data.regdatagdp  = tdata(1:end-1, [1:15    17:20 21 22:end]);
    data.regdatapgdp = tdata(2:end-1, [1:15 16 17:20    22:end]);
        
    %dates corresponding to the left hand side variable, one observation
    %lost to initial differencing, one observation lost to multistep
    data.tseriesgdp = rdata(3:end-1,1);
    data.tseriespgdp = rdata(4:end-1,1);
    data.recdatesgdp = recdates(2:end-1,1);
    data.recdatespgdp = recdates(3:end-1,1);

elseif h==4
    
    j = 1;
    gdp  = tdata(:,16); 
    pgdp = tdata(:,21);
    z = tdata(:, [1:15 17:20 22:end]);
    
    for i = 1:(size(gdp,1)-3)
        tempgdp(j,1)  = sum(gdp(i:i+3,1))/h;
        temppgdp(j,1) = sum(pgdp(i:i+3,1))/h;
        tempz(j,:) = sum(z(i:i+3,:),1)/h;
        j = j+1;
    end
 
        data.gdp = tempgdp(2:end,:);
        data.pgdp = temppgdp(3:end,:) - pgdp(2:end-4,:);
        zy = tempz(2:end,:);
        
        data.xgdp = tdata(1:end-4,16);
        data.xpgdp = diff(tdata(1:end-4,21),1);
        zx = tdata(1:end-4, [1:15 17:20 22:end]);
        
        data.regdatagdp  = tdata(1:end-4,[1:15    17:20 21 22:end]);
        data.regdatapgdp = tdata(2:end-4,[1:15 16 17:20    22:end]);
        
        data.tseriesgdp = rdata(7:end,1);
        data.tseriespgdp = rdata(8:end,1);
        
        data.recdatesgdp = recdates(6:end,1);
        data.recdatespgdp = recdates(7:end,1);
end

data.vnamegdp  = tlabels(:,[16 1:15    17:20 21 22:end]);
data.vnamepgdp = tlabels(:,[21 1:15 16 17:20    22:end]);