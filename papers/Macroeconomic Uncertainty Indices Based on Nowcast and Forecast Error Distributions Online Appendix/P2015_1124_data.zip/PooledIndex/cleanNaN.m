function data = cleanNaN(x)
% cleans the matrix x from the columns containing NaNs
data = [];
for i = 1:size(x,2)
    if sum(isfinite(x(:,i))==1) >= size(x,1)
        data = [data x(:,i)];
    end
end