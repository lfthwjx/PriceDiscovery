This code runs multiple ADL models and constructs the simple average forecast from these ADL models. 

PROGRAM FILE
main - runs the ADL models with the simple average forecast and constructs the uncertainty indices. 

SUPPORTING FILES
cleanNaN.m, nw.m, mbic.m - lag length selection based on BIC

DATA FILES
getData.m - obtains and organizes the data/transformations
Data.xls - data used in the estimation. The data file provides the sources of data.