% This is an executable file which runs various ADL forecasting models 
% and constructs the simple average forecast
clc; clear all; close all;

param.R = 40;
param.pmax = 4;
qn = floor(param.R^(1/4));
h = [1 4];

for hzn = h
    % Put the data in appropriate objects
    data = getData(hzn);

    param.tgdp = length(data.gdp);
    param.tpgdp = length(data.pgdp);
    
    dategdp = data.tseriesgdp(param.R+1:end,:);
    datepgdp = data.tseriespgdp(param.R+1:end,:);
    daterecgdp = data.recdatesgdp(param.R+1:end,:);
    daterecpgdp = data.recdatespgdp(param.R+1:end,:);

    vnamegdp = data.vnamegdp;
    vnamepgdp = data.vnamepgdp;
    
    ygdp = data.gdp;
    ypgdp = data.pgdp;
    xgdp = data.xgdp;
    xpgdp = data.xpgdp;
    regdatagdp = data.regdatagdp;
    regdatapgdp = data.regdatapgdp;
       
    % Creates matrices to store the forecasts
    forecastgdp = NaN(size(regdatagdp,2)+1,param.tgdp-param.R);
    forecastpgdp = NaN(size(regdatapgdp,2)+1,param.tpgdp-param.R);

    % OUTPUT GROWTH FORECASTS
    % one observation is lost to the out-of-sample forecast
    for i = param.R:(param.tgdp-1)
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % AR model 
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        roll_ygdp = ygdp(i-param.R+1:i,:);
        roll_xgdp = xgdp(i-param.R+1:i,:);
        
        param.l = mbic(roll_ygdp,ones(param.R,1),roll_xgdp, param.pmax);

        rgrgdp = ones(param.R-param.l+1,1);

        for j = 1:param.l
            rgrgdp = [rgrgdp roll_xgdp(param.l-j+1:end-j+1,:)];
        end
        
        beta = regress(roll_ygdp(param.l:end,:),rgrgdp);
          
        oosgdp = [1 xgdp(i+1,:) rgrgdp(end,2:end-1)];
        forecastgdp(1,i-param.R+1) = (ygdp(i+1,1) - oosgdp*beta);

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Models with Additional Regressors
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        for k = 1:size(regdatagdp,2)
            roll_reggdp = regdatagdp(i-param.R+1:i,k);

            if (isfinite(regdatagdp(i-param.R+1:i+1,k)) == 1) 
                param.rl = mbic(roll_ygdp(param.l:end),rgrgdp,roll_reggdp(param.l:end), param.pmax);
                param.ml = max(param.rl, param.l);

                rgrgdpreg = ones(param.R-param.ml+1,1);

                for j = 1:param.l
                    rgrgdpreg = [rgrgdpreg roll_xgdp(param.ml-j+1:end-j+1,:)];
                end
                for j = 1:param.rl
                    rgrgdpreg = [rgrgdpreg roll_reggdp(param.ml-j+1:end-j+1,:)];
                end

                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % ADL model 
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                beta = regress(roll_ygdp(param.ml:end,:),rgrgdpreg);
                
                oosgdp = [1 xgdp(i+1,:) rgrgdpreg(end,2:2+param.l-2)  regdatagdp(i+1,k)  rgrgdpreg(end,1+param.l+1:1+param.l+1+param.rl-2)]; %-2 are there since were are trying to truncate one observation for oos forecasting.
                forecastgdp(k+1,i-param.R+1) = ygdp(i+1,1)-oosgdp*beta;
           end
        end
    end
    
    clear poolforecastgdp sortedfe freqfe p u_ups u_down u
    poolforecastgdp = (sum(cleanNaN(forecastgdp(2:end,:)'),2)./size(cleanNaN(forecastgdp(2:end,:)'),2));
    
    % calculate the pits
    sortedfe = sort(poolforecastgdp);

    freqfe = cumsum(ones(size(sortedfe)));
    freqfe = freqfe./freqfe(end,1);

    % calculate the time series of the pits
    for ii = 1:length(dategdp)
        p(ii,:) = freqfe(sortedfe ==  poolforecastgdp(dategdp == dategdp(ii,1)));
    end

    for jj = 1:length(p)   
        u_ups(jj,1) = 0.5 + max(p(jj,1)-0.5,0);
        u_down(jj,1) = 0.5 + max(0.5-p(jj,1),0);
        u(jj,1) = 0.5 + abs(p(jj,1)-0.5);
    end

    grayColor = [1 1 1] * 0.7; 
    figure
    bar(dategdp,daterecgdp*4,'FaceColor', grayColor, 'EdgeColor',grayColor)
    hold on
    bar(dategdp, u_down, 'FaceColor',[0,0,1],'EdgeColor',[0,0,1])
    hold on
    bar(dategdp, u_ups, 'FaceColor',[0,1,0],'EdgeColor',[0,1,0])
    hold on
    plot(dategdp, 0.5*ones(size(dategdp)), '-k', 'LineWidth', 2)
    hold off
    box on
    legend('Recession Dates','U_{t+h}^-', 'U_{t+h}^+','Location','North', 'Orientation','Horizontal')
    title(strcat('Uncertainty in Pooled Model of Output Growth at horizon h=',num2str(hzn)))
    ylim([0.5 1.1])
    xlim([min(dategdp) max(dategdp)])
   

    % INFLATION FORECASTS
    % one observation is lost to the out-of-sample forecast
    for i = param.R:(param.tpgdp-1)
        % AR model
        roll_ypgdp = ypgdp(i-param.R+1:i,:);
        roll_xpgdp = xpgdp(i-param.R+1:i,:);

        param.pl = mbic(roll_ypgdp,ones(param.R,1),roll_xpgdp, param.pmax);

        rgrpgdp = ones(param.R-param.pl+1,1);

        for j = 1:param.pl
            rgrpgdp = [rgrpgdp roll_xpgdp(param.pl-j+1:end-j+1,:)];
        end

        beta = regress(roll_ypgdp(param.pl:end,:),rgrpgdp);
  
        oospgdp = [1 xpgdp(i+1,:) rgrpgdp(end,2:end-1)];
        densforecastpgdp(1,i-param.R+1) = ypgdp(i+1,1) - oospgdp*beta;
    
        for k = 1:size(regdatapgdp,2)
            roll_regpgdp = regdatapgdp(i-param.R+1:i,k);

            if (isfinite(regdatapgdp(i-param.R+1:i+1,k)) == 1) 
                param.prl = mbic(roll_ypgdp(param.pl:end),rgrpgdp,roll_regpgdp(param.pl:end), param.pmax);
                param.pml = max(param.prl, param.pl);

                rgrpgdpreg = ones(param.R-param.pml+1,1);

                for j = 1:param.pl
                    rgrpgdpreg = [rgrpgdpreg roll_xpgdp(param.pml-j+1:end-j+1,:)];
                end
                for j = 1:param.prl
                    rgrpgdpreg = [rgrpgdpreg roll_regpgdp(param.pml-j+1:end-j+1,:)];
                end

                % ADL models
                beta = regress(roll_ypgdp(param.pml:end,:),rgrpgdpreg);
                oospgdp = [1 xpgdp(i+1,:) rgrpgdpreg(end,2:2+param.pl-2)  regdatapgdp(i+1,k)  rgrpgdpreg(end,1+param.pl+1:1+param.pl+1+param.prl-2)]; %-2 are there since were are trying to truncate one observation for oos forecasting.
                forecastpgdp(k+1,i-param.R+1) = ypgdp(i+1,1)- oospgdp*beta;           
            end
        end
    end
    
    clear poolforecastpgdp sortedfe freqfe p u_ups u_down u
    poolforecastpgdp = (sum(cleanNaN(forecastpgdp(2:end,:)'),2)./size(cleanNaN(forecastpgdp(2:k+1,:)'),2));
   
    % calculate the pits
    sortedfe = sort(poolforecastpgdp);

    freqfe = cumsum(ones(size(sortedfe)));
    freqfe = freqfe./freqfe(end,1);

    % calculate the time series of the pits
    for ii = 1:length(datepgdp)
        p(ii,:) = freqfe(sortedfe ==  poolforecastpgdp(datepgdp == datepgdp(ii,1)));
    end

    for jj = 1:length(p)   
        u_ups(jj,1) = 0.5 + max(p(jj,1)-0.5,0);
        u_down(jj,1) = 0.5 + max(0.5-p(jj,1),0);
        u(jj,1) = 0.5 + abs(p(jj,1)-0.5);
    end
   
    figure
    bar(datepgdp,daterecpgdp*4,'FaceColor', grayColor, 'EdgeColor',grayColor)
    hold on
    bar(datepgdp, u_down, 'FaceColor',[0,0,1],'EdgeColor',[0,0,1])
    hold on
    bar(datepgdp, u_ups, 'FaceColor',[0,1,0],'EdgeColor',[0,1,0])
    hold on
    plot(datepgdp, 0.5*ones(size(datepgdp)), '-k', 'LineWidth', 2)
    hold off
    box on
    legend('Recession Dates','U_{t+h}^-', 'U_{t+h}^+','Location','North', 'Orientation','Horizontal')
    title(strcat('Uncertainty in Pooled Model of Inflation at horizon h=',num2str(hzn)))
    ylim([0.5 1.1])
    xlim([min(datepgdp) max(datepgdp)])
end

disp('Program Complete')